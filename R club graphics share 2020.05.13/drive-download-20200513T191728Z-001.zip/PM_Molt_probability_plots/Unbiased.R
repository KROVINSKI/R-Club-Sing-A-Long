
##################################################
# An unbiased method for determing presentation order
###################################################

# Vector of presenters
presenters <- c("Becca", "Garrett", "Gary", "Krista", "Paul")
# random sample all presenter without replacement
sample(presenters)

